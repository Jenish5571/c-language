#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,k;
	clrscr();

	for(i=0; i<=5 ; i++)
	{
		for(j=0; j<=2*i; j++)
		{
			printf(" ");
		}
		for(k=0; k<= 4-i; k++)
		{
			printf("%d ",k+1);
		}
		printf("\n");
	}

	getch();
}