#include<stdio.h>
#include<conio.h>
void main()
{
	int i,j,a,b=1;

	printf("emter the value :");
	scanf("%d",&a);
	clrscr();

	for(i=1; i<=a  ; i++)
	{
		for(j=1 ;j<=i ;j++)
		{
			printf("%d ",b);
			b++;
		}
		printf("\n");
	}

	getch();
}